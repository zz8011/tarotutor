import{m as C}from"./mentors-i5mKZful.js";import{getCardById as k}from"./tarotCards-lnXr-Wo7.js";import{s as $,a as A}from"./useAppStore-C9AlyxEK.js";import{j as m}from"./animation-DhXyLkLc.js";const I={eastern:{id:"eastern",label:"东方秘语塔罗",visualGuide:"这一套牌强调东方神秘气质、华丽纹样、柔和光影与仪式感。回答时先抓住人物姿态、器物、空间关系和氛围，再把画面转成牌义，不要只背通用韦特术语。若牌面里有明显的金色、饰纹、神话气息或层次丰富的背景，就优先围绕这些元素展开。",interpretationRule:"若当前图像的细节和标准韦特记忆有差异，以当前画面为准；不要把另一套牌的标志性元素硬套过来。用户已经说出的观察优先级最高，导师应围绕用户看到的画面补充，而不是推翻它。"},"chinese-ink":{id:"chinese-ink",label:"水墨塔罗",visualGuide:"这一套牌强调水墨、留白、线条、层次和东方意境。回答时优先描述墨色、构图、服饰、道具、题字、印章和画面留白，再解释它们对应的含义。若牌面里出现山水、飞鸟、楼阁、云气或手绘笔触，就优先围绕这些元素展开，而不是讲西式华丽装饰。",interpretationRule:"尽量用当前图像里能看见的元素来解读，不要只复述通用牌义；如果细节更克制，就用更含蓄的语言表达。用户已经说出的观察优先级最高，导师应围绕用户看到的画面补充，而不是推翻它。"}};function T(t){return I[t]}function h(t){const n=t?C.find(o=>o.id===t):void 0,e=`你是一位资深的塔罗牌导师，精通韦特塔罗体系。你的职责是帮助用户学习和理解塔罗牌。

## 核心原则
1. 用温暖、启发性的语言引导学习者
2. 结合心理学、神话学和象征学知识
3. 鼓励用户联系自身经历，但不要做过度的心理诊断
4. 每次回复控制在 200-400 字，保持简洁有力
5. 使用 Markdown 格式，适当分段

## 回复结构
- 先给出核心观点（1-2句话）
- 展开解释象征意义
- 联系用户的情境给出建议
- 以启发性问题结尾`;return n?`${e}

## 你的导师风格：${n.name}
${n.personality||""}

### 教学特点
${n.teachingStyle||"温和引导，循序渐进"}

### 语言风格
${n.personality||"温暖、富有洞察力"}
`:e}function d(t){const n=T(t);return[`当前牌组：${n.label} (${t})`,`牌组视觉风格：${n.visualGuide}`,`解读约束：${n.interpretationRule}`,"硬性规则：只把当前牌面里能确认的元素说成事实；如果通用牌义或另一套牌的细节和当前画面冲突，优先按当前牌组和用户观察来讲。","学习优先级：用户对牌面的观察 > 当前牌组视觉语言 > 通用牌义。"].join(`
`)}function g(t){return[`通用图像参考（仅作辅助，不可与当前牌组冲突时硬套）：${t.description}`,`图像符号：${t.imageSymbol}`].join(`
`)}function b(t,n,e,o,r="eastern"){var c;const s=h(),i=d(r),a=[`当前学习的卡牌：${t.name} / ${t.chineseName}（编号 ${t.id}）`,`牌组：${r}`,`元素：${t.element||"无"}`,`关键词：${((c=t.keywords)==null?void 0:c.join("、"))||"暂无"}`,g(t),n==="upright"?`正位含义：${t.uprightMeaning}`:`逆位含义：${t.reversedMeaning}`,`行星关联：${t.planet||"暂无"}`,`数秘学：${t.numerology||"暂无"}`,"学习规则：","1. 先回应用户刚刚看到的牌面元素，再给标准讲解。","2. 用户观察到的细节优先级最高，不要推翻用户的观察。","3. 不要把未确认的细节说成事实，也不要把另一套牌的风格硬套到这张牌上。",'4. 讲解时先说"你看到了什么"，再说"它通常意味着什么"，最后做总结。'].join(`
`),u=[{role:"system",content:`${s}

${i}

${a}`}],l=o.slice(-10);for(const p of l)u.push({role:p.role,content:p.content});return u.push({role:"user",content:e}),u}function R(t,n,e,o=t.cardDeck||"eastern"){var u;const r=h(e),s=d(o);let i="";for(const l of t.positions)if(l.cardId!=null){const c=k(l.cardId);c&&(i+=[`- ${l.name}（${l.meaning}）`,`  牌名：${c.name} / ${c.chineseName}`,`  位置：${l.orientation==="upright"?"正位":"逆位"}`,`  关键词：${((u=c.keywords)==null?void 0:u.join("、"))||"暂无"}`,`  ${g(c)}`,`  ${l.orientation==="upright"?`正位含义：${c.uprightMeaning}`:`逆位含义：${c.reversedMeaning}`}`].join(`
`)+`
`)}const a=["我进行了一次牌阵占卜。",`我的问题：${n||"没有特定问题，想要一般指引"}`,`当前牌组：${o}`,"","牌阵结果：",i.trim(),"","请为我解读这个牌阵，要求如下：","1. 先说明每张牌在自己位置上的含义。","2. 结合当前牌组的视觉风格来组织语言，但不要强行编造未确认的细节。","3. 讲清楚牌与牌之间的关系、故事线和变化方向。","4. 给出具体、可执行的建议。","5. 保持温暖、清晰、有层次的语气。","6. 最后用一句简洁有力的话总结核心启示。","输出格式要求：","- 使用 Markdown 小标题组织内容，例如：# 核心启示、# 牌位解读、# 关联故事线、# 行动建议、# 一句话总结。","- 每个小标题下写 1-2 个自然段。","- 段落之间必须空一行。","- 不要把所有内容写成一整段。"].join(`
`);return[{role:"system",content:`${r}

${s}`},{role:"user",content:a}]}function j(t,n,e="eastern"){const o=h(),r=d(e),s=[`今日抽到的卡牌：${t.name} / ${t.chineseName}`,`牌组：${e}`,`位置：${n==="upright"?"正位":"逆位"}`,g(t),"请提供：","1. 今日能量概述（100字内）","2. 具体指引和建议","3. 一个今天可以实践的小行动","4. 一句温暖的结尾","请保持分段清晰，不要把所有内容写成一整段。"].join(`
`);return[{role:"system",content:`${o}

${r}`},{role:"user",content:s}]}const v={dev:{baseURL:"http://localhost:3001"}};function L(t){try{const n=new URL(t);if(n.protocol!=="http:"&&n.protocol!=="https:")return console.error(`[AI Config] 拒绝不安全的代理协议: ${n.protocol}`),"";const e=n.hostname;return e==="localhost"||e==="127.0.0.1"||e.startsWith("192.168.")||e.startsWith("10.")||e.startsWith("172.")?(console.error(`[AI Config] 生产环境禁止内网代理地址: ${t}`),""):t}catch{return console.error(`[AI Config] 无效的代理 URL: ${t}`),""}}const f=L(v.dev.baseURL),y=typeof wx<"u"&&typeof wx.request=="function";async function x(t,n,e={}){const{temperature:o=.7,maxTokens:r=2048}=e;if(y)return new Promise((a,u)=>{wx.cloud.callFunction({name:t,data:{messages:n,temperature:o,maxTokens:r},success:l=>{var p,P;const c=l;(p=c.result)!=null&&p.error?u(new Error(c.result.error)):a($(((P=c.result)==null?void 0:P.result)||""))},fail:l=>u(new Error(String(l)))})});if(!f)throw new Error("未配置 API 代理地址，请在 .env.local 中设置 VITE_API_PROXY_URL");const s=await fetch(`${f}/api/${t}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:n,temperature:o,maxTokens:r}),signal:AbortSignal.timeout(3e4)});if(!s.ok)throw new Error(`代理请求失败: ${s.status}`);const i=await s.json();if(i.error)throw new Error(i.error);return $(i.result||"")}async function w(t,n={}){const{temperature:e=.7,maxTokens:o=2048}=n;if(!y&&!f)throw new Error("[AI Service] 未配置 API 代理地址。请在 .env.local 中设置 VITE_API_PROXY_URL，或确保在微信小程序环境中运行。");return x("tarot-chat",t,{temperature:e,maxTokens:o})}async function*_(t,n={}){const{temperature:e=.7,maxTokens:o=2048}=n;if(!y&&!f)throw new Error("[AI Service] 未配置 API 代理地址。请在 .env.local 中设置 VITE_API_PROXY_URL，或确保在微信小程序环境中运行。");const s=(await x("tarot-chat",t,{temperature:e,maxTokens:o})).split(new RegExp("(?<=。)|(?<=！)|(?<=？)|(?<=\\n)"));for(const i of s)i&&(yield $(i),await new Promise(a=>setTimeout(a,50)))}async function*W(t,n,e,o,r,s="eastern"){const i=b(t,n,e,o,s);if(r){const a=h(r),u=i[0].content,l=u.split(`

`),c=l.length>1?l.slice(1).join(`

`):u;i[0].content=a+`

`+c}yield*_(i,{temperature:.8,maxTokens:800})}async function V(t,n,e,o=t.cardDeck||"eastern"){const r=R(t,n,e,o);return w(r,{temperature:.7,maxTokens:1500})}async function X(t,n,e="eastern"){const o=j(t,n,e);return w(o,{temperature:.9,maxTokens:600})}const E=/[（(]([^（）()]{1,36})[）)]/g;function N(t){const n=t.trim();return/^[（(].+[）)]$/.test(n)?n.slice(1,-1).trim():t}function S(t){const n=[];let e=0,o=0;for(const r of t.matchAll(E)){const[s,i]=r,a=r.index??0;a>e&&n.push(t.slice(e,a)),n.push(m.jsx("span",{className:"ai-action",children:i},`action-${o++}`)),e=a+s.length}return e<t.length&&n.push(t.slice(e)),n.length||n.push(t),n}function U(t){const n=t.split(`
`).map(i=>i.trim()).filter(Boolean);if(n.length>1)return n;const e=t.trim();if(e.length<=84)return[e];const o=e.match(/[^。！？!?；;]+[。！？!?；;]?/g)||[e],r=[];let s="";for(const i of o){const a=s?`${s}${i}`:i;s&&a.length>42?(r.push(s.trim()),s=i):s=a}return s.trim()&&r.push(s.trim()),r.length?r:[e]}function O(t){const n=U(t),o=n.length===1&&/^[（(].+[）)]$/.test(n[0].trim())?"ai-paragraph ai-paragraph--action":"ai-paragraph";return m.jsx("p",{className:o,children:n.flatMap((r,s)=>{const i=S(N(r)),a=[];return s>0&&a.push(m.jsx("br",{},`br-${s}`)),a.push(...i),a})})}function Y({text:t,className:n}){const e=A(t);return e.length?m.jsx("div",{className:["ai-response",n].filter(Boolean).join(" "),children:e.map((o,r)=>m.jsx("div",{className:"ai-response__block",children:O(o)},`block-${r}`))}):null}export{Y as A,V as a,X as g,W as s};
