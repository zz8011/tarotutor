import{r as u}from"./vendor-CcjJ2j52.js";function v(m={}){const{color:r="var(--accent-gold)",count:o=8,spread:i=60}=m,a=u.useCallback(t=>{const c="touches"in t?t.touches[0].clientX:t.clientX,e="touches"in t?t.touches[0].clientY:t.clientY;for(let s=0;s<o;s++){const n=document.createElement("div");n.className="magic-particle";const l=Math.PI*2*s/o+Math.random()*.5,d=i*(.5+Math.random()*.5),h=Math.cos(l)*d,p=Math.sin(l)*d;n.style.cssText=`
        left: ${c}px;
        top: ${e}px;
        --tx: ${h}px;
        --ty: ${p}px;
        background: radial-gradient(circle, ${r} 0%, transparent 70%);
      `,document.body.appendChild(n),setTimeout(()=>n.remove(),1e3)}},[r,o,i]);u.useEffect(()=>{const t=e=>a(e),c=e=>a(e);return document.addEventListener("click",t),document.addEventListener("touchstart",c),()=>{document.removeEventListener("click",t),document.removeEventListener("touchstart",c)}},[a])}export{v as u};
